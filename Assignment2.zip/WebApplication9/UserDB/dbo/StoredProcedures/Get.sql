﻿CREATE PROCEDURE [dbo].[Get]
@rollNo int
AS
BEGIN
SELECT rollNo, Name, familyName, Address, contactNumber
from [dbo].[Students]
where rollNo = @rollNo;
end