﻿CREATE PROCEDURE [dbo].[Delete]
@rollNo int
AS BEGIN
DELETE 
from [dbo].[Students]
where rollNo = @rollNo;
end

