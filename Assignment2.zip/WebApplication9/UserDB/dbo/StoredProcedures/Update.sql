﻿CREATE PROCEDURE [dbo].[Update]
@rollNo INT ,
	@Name NVARCHAR(255) ,
	@familyName NVARCHAR(255) ,
	@contactNumber NVARCHAR(255) ,
	@Address NVARCHAR(255) 
AS
BEGIN
update [dbo].[Students]
set
	Name  = @Name  ,
	familyName =@familyName  ,
	contactNumber =@contactNumber  ,
	Address =@Address 
where rollNo = @rollNo;
end
