﻿CREATE PROCEDURE [dbo].[Insert]
	
	@rollNo INT ,
	@Name NVARCHAR(255) ,
	@familyName NVARCHAR(255) ,
	@contactNumber NVARCHAR(255) ,
	@Address NVARCHAR(255) 
AS
BEGIN
	INSERT INTO [dbo].[Students](rollNo, Name, familyName, Address, contactNumber)
	VALUES(@rollNo ,
	@Name  ,
	@familyName  ,
	@contactNumber  ,
	@Address );
END
