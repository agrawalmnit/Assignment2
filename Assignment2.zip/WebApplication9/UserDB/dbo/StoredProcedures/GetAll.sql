﻿CREATE PROCEDURE [dbo].[GetAll]
AS
BEGIN
select rollNo, Name, familyName, Address, contactNumber
from dbo.[Students];
end
