﻿using DataAccess.DBAccess;
using DataAccess.Models;
using DataAccess.Data;
using DataAccess.Domain;
namespace DataAccess.Data
{
    public class UserData : IUserData
    {
        private readonly ISqlDataAccess _db;

        public UserData(ISqlDataAccess db)
        {
            _db = db;
        }

        public async Task<List<Students2>> GetUsers()
        {
            var res = await _db.LoadData<Students2, dynamic>(storedProcedure: "dbo.GetAll", new { });
            return  res.ToList();
        }

        
        public async Task<Students2> GetUser(int rollNo)
        {
            var results = await _db.LoadData<Students2, dynamic>
                (
                storedProcedure: "dbo.Get",
                    new { rollNo = rollNo});

            return results.FirstOrDefault();
        }

        public async Task<bool> InsertUser(Students2 user)
        {

            try {  _db.SaveData(storedProcedure: "dbo.Insert", new { user.Name, user.familyName }); }

            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }



        public async Task<bool> UpdateUser(Students2 user)
        {
            try
            {


                _db.SaveData(storedProcedure: "dbo.Update", user);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public async Task<bool> DeleteUser(int rollNo)
        {

            try { _db.SaveData(storedProcedure: "dbo.Delete", new { rollNo = rollNo }); }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
}


}

