﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;
using DataAccess.Domain;
namespace DataAccess.Data
{


    public interface IUserData
    {
         Task<bool> DeleteUser(int rollNo);
         Task<bool> InsertUser(Students2 user);
        Task<List<Students2>> GetUsers();
        Task<bool> UpdateUser(Students2 user);
        Task<Students2> GetUser(int rollNo);
    }
}


