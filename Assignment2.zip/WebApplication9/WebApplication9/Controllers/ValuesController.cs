﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DataAccess;
using System.Security.Cryptography.X509Certificates;

namespace WebApplication9.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class ValuesController : ControllerBase
    {

        public readonly IuserService _userService;
        
        public ValuesController(IuserService userService)
        {
            _userData = userService;
        }

        [HttpGet]
        [Route("GetUser")]
        public async Task<List<Students>> GetAll()
        {
           var res = new List<Students>();
            try
            {
                 res = await _userService.GetAll();
                 
            }
            catch (Exception e)
            {

                throw;
            }
            return res;
        }

        [HttpGet]
        [Route("get")]
        public async Task<Students> Get(int rollNo)
        {
            var res2 = new Students();
            try
            {
                 res2 = await _userService.Get(rollNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return res2;
        }
        [HttpPut]
        [Route("put")]
        public async Task<bool> Create(Students user)
        {
            try
            {
                await _userService.Create(user);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
        [HttpPost]
        [Route("post")]
        public async Task<bool> Update(Students user)
        {

            try
            {
                await _userService.Update(user);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
        [HttpDelete]
        [Route("delete")]
        public async Task<bool> Delete(int rollNo)
        {

            try
            {
                await _userService.Delete(rollNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

    }
}
