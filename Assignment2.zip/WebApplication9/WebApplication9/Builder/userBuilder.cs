﻿using AutoMapper;
using DataAccess.Domain;

namespace WebApplication9.Builder
{
    public class userBuilder : IuserBuilder
    {
        private readonly IMapper _mapper;
        public userBuilder(IMapper mapper)
        {
            _mapper = mapper;
        }
        public Students Build(Students2 students2)
        {
            return _mapper.Map<Students>(students2);    
        }

        public Students2 Build(Students students)
        {
            return _mapper.Map<Students2>(students);
        }
    }

}
