﻿using DataAccess.Domain;

namespace WebApplication9.Builder
{
    public interface IuserBuilder
    {
        Students Build(Students2 students2);
        Students2 Build(Students res);
    }
}
