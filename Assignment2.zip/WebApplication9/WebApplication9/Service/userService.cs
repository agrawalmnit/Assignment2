﻿using DataAccess.DBAccess;
using DataAccess.Models;
using DataAccess.Data;
using DataAccess.Domain;
using System.Xml.Linq;
using WebApplication9.Builder;
using Microsoft.AspNetCore.Mvc;
using AutoMapper.Configuration.Conventions;
using DataAccess.Models;
using AutoMapper;

namespace DataAccess.Data
{
    public class userService
    {
        private readonly IUserData _userdata;
        private readonly IuserBuilder _automap;
        public userService(IUserData userdata, IuserBuilder automap)
        {
            _userdata = userdata;
            _automap = automap;
        }

        public async Task<List<Students2>> GetAll()
        {
           var students = await _userdata.GetUsers();
           return students.Select(x => _automap.Build(x)).ToList();
        }

        public async Task<Students2> Get(int rollNo)
        {
            var student = await _userdata.GetUser(rollNo);
            var res = _automap.Build(student);
            return res;
        }


        public async Task<bool> Update(Students2 st2)
        {
            try
            {
                _userdata.UpdateUser(st2);
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public async Task<bool> Create(Students2 st2)
        {
            try
            {
                _userdata.InsertUser(st2);
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }



        public async Task<bool> Delete(int rollNo)
        {
            try
            {
                _userdata.DeleteUser(rollNo);
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
    }
}